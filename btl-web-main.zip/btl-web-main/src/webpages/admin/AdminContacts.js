
import { Link } from 'react-router-dom';
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const AdminContacts = () => {
  const [contacts, setContacts] = useState([]);

  useEffect(() => {
    const getContacts = async () => {
      const res = await axios.get('/api/contacts');
      setContacts(res.data);
    };

    getContacts();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`/api/contacts/${id}`);
      setContacts(contacts.filter((contact) => contact._id !== id));
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <h2>Contacts</h2>
      <table className='AdminContacts-text'>
        <thead>
          <tr>
            <th className='AdminContacts-table' >Name</th>
            <th className='AdminContacts-table' >Email</th>
            <th className='AdminContacts-table' >Subject</th>
            <th className='AdminContacts-table' >Message</th>
            <th className='AdminContacts-table' >Action</th>
          </tr>
        </thead>
        <tbody>
          {contacts.map((contact) => (
            <tr key={contact._id}>
              <td className='AdminContacts-info'>{contact.name}</td>
              <td className='AdminContacts-info'>{contact.email}</td>
              <td className='AdminContacts-info'>{contact.subject}</td>
              <td className='AdminContacts-info'>{contact.message}</td>
              <td className='AdminContacts-info'>
                <button className='AdminContacts-btn' onClick={() => handleDelete(contact._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default AdminContacts;
