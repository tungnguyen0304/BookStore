import Webpages from './webpages';
import ScrollTopButton from './webpages/ScrollTopButton';

export default function App() {
    return (
        <>
            <Webpages />
            <ScrollTopButton />
        </>
    );
}